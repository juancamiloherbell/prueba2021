import java.io.*;
import javax.swing.JOptionPane;

public class Main {

     static String calendario;
    
     static FileWriter fill = null;
    
     static String ImprimirDias(int mes, String dia){
         
          int i;
          int j = 0;
          // Creo un arreglo llamado DiasSemana para los dias de la semana
          String[] DiasSemana = {" D \n", " L \n", " M \n", " X \n", " J \n", " V \n", " S \n"}; 
          // Creo la variable ResulDia que es donde se almacenaran los dias y ese sera el valor a imprimir
          String ResulDia = "  ";
         
          // Inicializo las posiciones del arreglo con los dias de la semana
          switch(dia){
                case "D": j = 0;
                     break;
                case "L": j = 1;
                     break;
                case "M": j = 2;
                     break;
                case "X": j = 3;
                     break;
                case "J": j = 4;
                     break;
                case "V": j = 5;
                     break;
                case "S": j = 6;
                     break;
          }
         
//Creo un switch para el mes donde para cada mes existe un caso, para diferenciar los meses que constan de 28, 30 o 31 dias
          switch(mes){
         //Para los casos 1, 3, 5, 7, 8, 10, 12 son los meses que contienen 31 dias 
                case 1:
                case 3:
                case 5:
                case 7:
                case 8:
                case 10:
                case 12:
                    //el for lo que hace es validar los numeros que sean desde 1 hasta < 32 
                     for(i = 1; i < 32; i++){
                          ResulDia = ResulDia + String.valueOf(i) + DiasSemana[j];
                          //En el if especificamos que cuando j que son los dias de la semana lleguen a 6 se inicialice nuevamente en 0
                          if(j == 6)
                               j = 0;
                          else
                               j++;
                     }
                     break;
                //Para los casos 4, 6, 9 y 11 son los meses que contienen 30 dias 
                case 4:
                case 6:
                case 9:
                case 11:
                     //el for lo que hace es validar los numeros que sean desde 1 hasta < 31 es decir hasta 30 dias  
                    for(i = 1; i < 31; i++){
                          ResulDia = ResulDia + String.valueOf(i) + DiasSemana[j];
                          //En el if especificamos que cuando j que son los dias de la semana lleguen a 6 se inicialice nuevamente en 0
                          if(j == 6)
                               j = 0;
                          else
                               j++;
                     }
                     break;
                //Por ultimo tenemos el caso2 que es para el mes de febrero que solo tiene 28 dias
                case 2:
                    //el for lo que hace es validar los numeros que sean desde 1 hasta < 29 es decir hasta los 28 dias 
                    for(i = 1; i < 29; i++){
                          ResulDia = ResulDia + String.valueOf(i) + DiasSemana[j];
                          //En el if especificamos que cuando j que son los dias de la semana lleguen a 6 se inicialice nuevamente en 0
                          if(j == 6)
                               j = 0;
                          else
                               j++;
                     }
                     break;
          }
          //Imprimo el resultado del calendario
          JOptionPane.showMessageDialog(null,"CALENDARIO PARA MES "+mes +" ES: \n "+ResulDia);
         
          return ResulDia;
        
     
}
    
     static void ElMes(int mes, String dia){
         // Concateno para crear el nombre del fichero
          calendario = "mes" + mes + ".txt"; 
         
          
          
          try{
              
                // creacion del fichero
                fill = new FileWriter(calendario); 
                // Llamo la funcion creada en el String
                fill.write(ImprimirDias(mes, dia)); 
          }
          catch(FileNotFoundException e){
                e.printStackTrace();
          }
          catch(IOException e){
                e.printStackTrace();
          }
          finally{
                try{
                     fill.close();
                }
                catch(IOException e){
                     e.printStackTrace();
                }
          }
          
          
         
     }
    
     public static void main(String[] args) {
         //se crean las variables para mes y dia
          int mes;
          String dia;
         //Aqui se preguntan los valores para cada uno y se almacena cada una en su respectiva variable.
          JOptionPane.showMessageDialog(null," PRUEBA#4   REALIZADO POR: JOHAN FERNANDO CRUZ GUEVARA"    );
         
         mes = Integer.parseInt(JOptionPane.showInputDialog("Escribe número de mes"));
         dia= JOptionPane.showInputDialog("Escribe día inicio del mes");
        
         ElMes(mes, dia);

     }
}

  