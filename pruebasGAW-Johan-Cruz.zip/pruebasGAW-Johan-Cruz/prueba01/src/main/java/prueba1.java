/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import javax.swing.JOptionPane;

/**
 *
 * @author johan
 */
public class prueba1 {
     public static void main (String [] args){
        
        
        String letras = "SUTPAGMELC";
        char[] ArregloLetras;
        ArregloLetras=letras.toCharArray();
        
        
        String numeros = "0123456789";
       char[] ArregloNumeros;
       ArregloNumeros=numeros.toCharArray();
        int num=0;
    boolean entradaNumerica= true;
    
        
        numeros=JOptionPane.showInputDialog("Introduzca un número de 10 digitos");   
        
   while(num==0){
        if (numeros.length() ==10) {
        
        num=1;
         
     }else { numeros=JOptionPane.showInputDialog ("INTRODUZCA UN NUMERO DE 10 DIGITOS");
     
        }
    }
        
    for (int i = 0; i < numeros.length(); i++) {
            
            
            if (Character.isDigit(numeros.charAt(i))==false) {
                JOptionPane.showMessageDialog (null," ENTRADA NO VALIDA, DIGITE SOLO NUMEROS");
                entradaNumerica=false;
                break;
                    
            } else { JOptionPane.showMessageDialog(null," ENTRADA VALIDA");

    }
         
      char[]datos;
      
      datos = numeros.toCharArray();
        
      char resultado = 0;
      
      String [] ResultadoFinal= new String[10];
      
      for (int a = 0; a < 10; a++) {
            for (int j = 0; j < 10; j++) {
                if (datos[a] == ArregloNumeros[j]) {
                    resultado = ArregloLetras[j];
                    ResultadoFinal[a] = String.valueOf(resultado);
                }
            }

        }
      
      StringBuffer Conversion = new StringBuffer();
        for (int x = 0; x < 10; x++) {
            Conversion = Conversion.append(ResultadoFinal[x]);
        }
        String arreglo = Conversion.toString();
        JOptionPane.showMessageDialog(null,"EL RESULTADO FINAL ES:  " + arreglo);

    }
      
        }
    
}
